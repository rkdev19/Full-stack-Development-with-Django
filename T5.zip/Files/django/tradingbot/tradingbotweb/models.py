from django.db import models

# Create your models here.
class Currency(models.Model):
    symbol = models.CharField(max_length=10, primary_key=True )
    usd_value = models.DecimalField(max_digits=10, decimal_places=2, default=1.0)

class Transaction(models.Model):
    origin_currency = models.ForeignKey('Currency', on_delete=models.CASCADE, related_name='origin_currency')
    destination_currency = models.ForeignKey('Currency', on_delete=models.CASCADE, related_name='destination_currency')
    destination_currency_value = models.DecimalField(max_digits=10, decimal_places=2)
    original_currency_value = models.DecimalField(max_digits=10, decimal_places=2)
    commission = models.DecimalField(max_digits=10, decimal_places=2, default=0.0)
    exchange_date = models.DateTimeField(auto_now_add=True)

class CurrencyHistory(models.Model):
    symbol = models.ForeignKey('Currency', on_delete=models.CASCADE)
    usd_value = models.DecimalField(max_digits=10, decimal_places=6, default=1.8)
    created_at = models.DateTimeField(auto_now_add=True)
