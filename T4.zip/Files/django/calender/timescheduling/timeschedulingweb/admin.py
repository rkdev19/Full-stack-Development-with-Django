from django.contrib import admin
from .models import TimeSlot

# Register your models here.
admin.site.register(TimeSlot)
