from django.contrib import admin
from .models import Currency, Transaction

# Register your models here.
admin.site.register(Currency)
admin.site.register(Transaction)
